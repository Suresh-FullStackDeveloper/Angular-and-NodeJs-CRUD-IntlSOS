const mongoose = require("mongoose");

const db = require("./models");
// Doctors 
const createDoctors = function(doctors) {
  return db.doctors.create(doctors).then(docDoctors => {
    console.log("\n>> Created Tutorial:\n", docDoctors);
    return docDoctors;
  });
};

//Create Patients
const createPatients = function(doctorsId, patients) {
  return db.Patients.create(patient).then(docPatient => {
    console.log("\n>> Created patients:\n", docPatient);

    return db.Doctors.findByIdAndUpdate(
      DoctorsId,
      { $push: { patients: docPatients._id } },
      { new: true, useFindAndModify: false }
    );
  });
};

const getDoctorsWithPopulate = function(id) {
  return db.Doctors.findById(id)
    .populate("patients", "-_id -__v")
    .populate("patients", "name -_id")
    .select("-images._id -__v");
};


const run = async function() {
  var doctors = await createDoctors({
    title: "MongoDB One-to-Many Relationship example",
    author: "Doctors"
  });

  

  doctors = await createPatients(doctors._id, {
    username: "jack",
    text: "This is a great patients.",
    createdAt: Date.now()
  });
  console.log("\n>> Doctors:\n", doctors);

  doctors = await createPatients(doctors._id, {
    username: "mary",
    text: "Thank you, it helps me alot.",
    createdAt: Date.now()
  });
  console.log("\n>> doctors:\n", doctors);

  var patients = await createPatients({
    name: "Alam",
    description: " doctors"
  });

  doctors = await addDoctorsToPatients(doctors._id, patients._id);
  console.log("\n>> Doctors:\n", tutorial);

  doctors = await getTutorialWithPopulate(tutorial._id);
  console.log("\n>> populated Doctors:\n", tutorial);

  var newDoctors = await createTutorial({
    title: "Mongoose Doctors with examples",
    author: "leet"
  });

  await addDoctorsToPatients(newDoctors._id, patients._id);

  var doctors = await getDoctorsInPatients(patients._id);
  console.log("\n>> all Doctors in Cagetory:\n", doctors);
};

mongoose
  .connect("mongodb://localhost/local_db", {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => console.log("Successfully connect to MongoDB."))
  .catch(err => console.error("Connection error", err));

run();
