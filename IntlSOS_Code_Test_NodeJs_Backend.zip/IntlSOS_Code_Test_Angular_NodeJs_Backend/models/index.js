module.exports = {
 
  Doctors:require("./Doctors"),
  Patients:require("./Patients")
};
