const mongoose = require("mongoose");

const Patients = mongoose.model(
  "Patients",
  new mongoose.Schema({
    patientname: String,
    text: String,
    createdAt: Date
  })
);


//Mongoose One-to-Many (aLot) Relationship
const mongoose = require("mongoose");

const Patients1 = mongoose.model(
  "Patients1",
  new mongoose.Schema({
    name: String,
    description: String
  })
);

module.exports = Patients1;

const mongoose = require("mongoose");

const Doctors1 = mongoose.model(
  "Doctors",
  new mongoose.Schema({
    title: String,
    author: String,
    
    Patients: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Patients"
    }
  })
);

module.exports = Doctors1;

//Doctors1

