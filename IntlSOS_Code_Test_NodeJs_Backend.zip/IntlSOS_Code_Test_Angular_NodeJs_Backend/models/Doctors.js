const mongoose = require("mongoose");

const Doctors = mongoose.model(
  "Doctors",
  new mongoose.Schema({
    title: String,
    DoctorName: String,    
    Patients: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Patients"
      }
    ]
  })
);

module.exports = Doctors;
